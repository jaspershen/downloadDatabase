### downloadDatabase module

This module is used to download comment databases, such as HMDB, KEGG. Now verion0.0.1 only support 
HMDB.